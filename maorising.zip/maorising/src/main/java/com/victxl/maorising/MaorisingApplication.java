package com.victxl.maorising;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaorisingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaorisingApplication.class, args);
	}

}
