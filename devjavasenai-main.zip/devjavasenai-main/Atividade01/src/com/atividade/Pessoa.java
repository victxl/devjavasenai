package com.atividade;

public class Pessoa {
	// atributos
	private String nome;
	private String email;
	private String endereco;
	private String telefone;
	private String cpf;
	private String rg;
	private String cargo;
	private Object tipoSang;
	private int idade;
	private double peso;
	private double altura;
	private double salario;
	
	// construtor
	public Pessoa() {
		// TODO Auto-generated constructor stub
	}
	
	// métodos da classe
	public String doarDinheiro(double valor) {
		return null;
	}
	
	public double calcularImc() {
		return 0;
	}
	
	// getters e setters
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public Object getTipoSang() {
		return tipoSang;
	}

	public void setTipoSang(Object tipoSang) {
		this.tipoSang = tipoSang;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

}

	