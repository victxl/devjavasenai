package com.fragmento.netflixweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetflixwebApplication.class, args);
	}

}
