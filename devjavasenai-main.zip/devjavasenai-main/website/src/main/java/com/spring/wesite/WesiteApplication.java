package com.spring.wesite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WesiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(WesiteApplication.class, args);
	}

}
