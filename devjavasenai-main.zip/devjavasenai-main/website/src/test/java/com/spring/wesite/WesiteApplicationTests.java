package com.spring.wesite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WesiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
