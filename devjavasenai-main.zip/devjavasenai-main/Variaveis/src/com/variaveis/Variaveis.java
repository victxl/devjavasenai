package com.variaveis;

public class Variaveis {

	public static void main(String[] args) {
		//declaração de variáveis
	String nome;
	int idade;
	
	// atribui valores às variàveis
	nome = "Victor Henrique";
	idade= 35;
	
	System.out.printf("Bom noite %s, você tem somente %d",nome,idade);

}
}