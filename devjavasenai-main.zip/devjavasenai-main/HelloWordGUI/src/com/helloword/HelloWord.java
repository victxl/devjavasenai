
package com.helloword;
import javax.swing.JOptionPane;

public class HelloWord {

	public static void main(String[] args) {
		
		
		JOptionPane.showMessageDialog(null,"Alo, Mundo!");
		
		
	}

}
