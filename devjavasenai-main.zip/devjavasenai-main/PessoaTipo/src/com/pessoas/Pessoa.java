package com.pessoas;

public abstract class Pessoa {
	public int idPessoa;
	public String email;
	public String endereco;
	public String telefone;

	public Pessoa(int idPessoa) {
		this.idPessoa = idPessoa;
		
		
		
	}

}
