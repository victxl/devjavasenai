package com.pessoas;

public final class PessoaJuridica extends Pessoa {
	
	public String razaoSocial;
	public String nomeFantasia;
	public String cnpj;
	

	public PessoaJuridica(int idPessoa) {
		super(idPessoa);
			
	}

}
