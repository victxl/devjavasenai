package com.cadastro;

import javax.swing.JPanel;

public class CadastroEvento extends JPanel {

	/**
	 * Create the panel.
	 */
	public CadastroEvento() {

	}

}
