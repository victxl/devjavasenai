package com.relacao;

public interface IConta {
	//1 metodos 
	public String fazerDeposito(double valor);
	public String fazerSaque(double valor);
	

}
