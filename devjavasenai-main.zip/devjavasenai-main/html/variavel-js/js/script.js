// declaração de variaveis



let nome = 'Victor Henrique ';

alert(nome + 'Instale esse programa no seu computador agora, você esta correndo risco de vida.');

