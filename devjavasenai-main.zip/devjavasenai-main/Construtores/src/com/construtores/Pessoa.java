package com.construtores;

public class Pessoa {

	// 1 atributos
	public int idPessoa;
	public String nome;
	public String cpf;
	public String email;
	public String telefone;
	public String cidade;

	// 2 construtor
	public Pessoa() {

	}

	public Pessoa(int idPessoa) {
		this.idPessoa = idPessoa;
	}

}
