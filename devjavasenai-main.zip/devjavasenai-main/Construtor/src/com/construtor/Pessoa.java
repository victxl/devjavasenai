package com.construtor;

public class Pessoa {
	// 1º atributos
	public int idPessoa;
	public String nome;
	public String endereco;
	public String email;
	public String cpf;
	public String telefone;

	// 2º construtor
	public Pessoa(int idPessoa) {
		this.idPessoa = idPessoa;

	}

}
