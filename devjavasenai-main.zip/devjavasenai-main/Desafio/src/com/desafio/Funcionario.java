package com.desafio;

public class Funcionario {
	public int matricula;
	public String nome;
	public String nascimento;
	public String endereco;
	public String cargo;
	public Double salario;
	
	
	public Funcionario(int matricula) {
		
		this.matricula = matricula;
		
		
		
		
	}

}
